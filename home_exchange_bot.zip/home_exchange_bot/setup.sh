#!/bin/bash
set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo "╔══════════════════════════════════════╗"
echo "║     HomeExchange Bot — Setup         ║"
echo "╚══════════════════════════════════════╝"
echo ""

# ── 1. Перевірка Docker ──────────────────────────────────────────────────────
echo -e "${YELLOW}[1/5] Перевірка Docker...${NC}"
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Docker не встановлено. Встановлюємо...${NC}"
    curl -fsSL https://get.docker.com | sh
    sudo usermod -aG docker $USER
    echo -e "${GREEN}✅ Docker встановлено${NC}"
else
    echo -e "${GREEN}✅ Docker знайдено: $(docker --version)${NC}"
fi

if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null 2>&1; then
    echo -e "${RED}Docker Compose не знайдено. Встановлюємо...${NC}"
    sudo apt-get install -y docker-compose-plugin 2>/dev/null || \
    sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" \
        -o /usr/local/bin/docker-compose && sudo chmod +x /usr/local/bin/docker-compose
fi

# ── 2. Налаштування .env ─────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}[2/5] Налаштування токена...${NC}"

if [ -f ".env" ] && grep -q "BOT_TOKEN=." .env; then
    echo -e "${GREEN}✅ .env вже існує з токеном${NC}"
else
    cp .env.example .env

    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Щоб отримати токен:"
    echo "  1. Відкрийте Telegram"
    echo "  2. Знайдіть @BotFather"
    echo "  3. Надішліть /newbot"
    echo "  4. Введіть назву і username бота"
    echo "  5. Скопіюйте токен"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    read -p "Введіть BOT_TOKEN: " token
    if [ -z "$token" ]; then
        echo -e "${RED}❌ Токен не може бути порожнім${NC}"
        exit 1
    fi
    sed -i "s|BOT_TOKEN=.*|BOT_TOKEN=$token|" .env

    read -p "Ваш Telegram ID (необов'язково, натисніть Enter щоб пропустити): " admin_id
    if [ -n "$admin_id" ]; then
        sed -i "s|ADMIN_IDS=.*|ADMIN_IDS=$admin_id|" .env
    fi

    echo -e "${GREEN}✅ .env налаштовано${NC}"
fi

# ── 3. Збірка Docker образу ──────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}[3/5] Збірка Docker образу...${NC}"
docker compose build --quiet 2>/dev/null || docker-compose build --quiet
echo -e "${GREEN}✅ Образ зібрано${NC}"

# ── 4. Запуск ────────────────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}[4/5] Запуск бота...${NC}"
docker compose up -d 2>/dev/null || docker-compose up -d
sleep 3

# ── 5. Перевірка ─────────────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}[5/5] Перевірка статусу...${NC}"
if docker compose ps 2>/dev/null | grep -q "running" || \
   docker-compose ps 2>/dev/null | grep -q "Up"; then
    echo -e "${GREEN}✅ Бот запущено успішно!${NC}"
else
    echo -e "${RED}❌ Щось пішло не так. Перегляньте логи:${NC}"
    docker compose logs --tail=20 2>/dev/null || docker-compose logs --tail=20
    exit 1
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${GREEN}🎉 Бот запущено і працює!${NC}"
echo ""
echo "  Корисні команди:"
echo "  Логи:     docker compose logs -f"
echo "  Зупинити: docker compose down"
echo "  Рестарт:  docker compose restart"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
